"use client"

import { useContextProvider } from "./Context"
import { useRouter } from "next/navigation";

type Params = {
    textContent: string,
    src: string,
    type: string,   // defines the onClick action
    onClickFunction?: (e: any) => void, 
}
export default function Button({textContent, src, type, onClickFunction}:Params){
    // const {signedIn, setSignedIn} = useContextProvider();
    const router = useRouter();

    const onClick = () => {
                router.push(src);
    }

    return (
        <button onClick={onClickFunction ? onClickFunction : onClick} className="bg-lime-400 rounded-xl cursor-pointer shadow-md p-3 font-semibold active:translate-y-1 hover:bg-lime-500">
            {textContent}
        </button>
    )
}