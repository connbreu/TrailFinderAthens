"use client";

import Link from "next/link";
import Image from "next/image";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";


export default function Nav() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const user = session?.user;
  return (
    <nav className="flex items-center justify-between px-8 py-4 bg-white/90 backdrop-blur-md shadow-md sticky top-0 z-50">
      
      {/* Logo + Title */}
      <Link href="/" className="flex items-center gap-2">
        <Image src="/trail.svg" width={38} height={38} alt="Trail Logo" />
        <span className="text-2xl font-bold text-green-700 hover:text-green-800 transition">
          TrailFinder
        </span>
      </Link>

      {/* Nav Links */}
      <div className="hidden md:flex gap-6 text-gray-700 font-medium">
        <Link href="/trails" className="hover:text-green-700 transition">
          Trails
        </Link>
        <Link href="/events" className="hover:text-green-700 transition">
          Groups & Events
        </Link>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-4">

        {status === "loading" && (
          <span className="text-gray-600">Loading...</span>
        )}

        {user ? (
          <>
            <span className="text-gray-700 font-medium">
              Hello, <span className="font-semibold">{user.name}</span>
            </span>

            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="border border-green-600 text-green-700 px-4 py-2 rounded-md hover:bg-green-50 transition"
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => router.push("/signin")}
              className="border border-gray-300 px-4 py-2 rounded-md hover:bg-gray-100 transition"
            >
              Login
            </button>

            <button
              onClick={() => !user && router.push("/signup")}
              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition"
            >
              Sign Up
            </button>
          </>
        )}

      </div>
    </nav>
  );
}
