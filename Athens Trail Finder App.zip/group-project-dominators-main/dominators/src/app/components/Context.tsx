'use client';

import { createContext, useContext, useState } from "react";

type ContextType = {
  signedIn: boolean;
  login: () => void;
  logout: () => void;
};

const Context = createContext<ContextType | undefined>(undefined);

export function ContextProvider({ children }: { children: React.ReactNode }) {
  const [signedIn, setSignedIn] = useState(false);

  const login = () => setSignedIn(true);
  const logout = () => setSignedIn(false);

  return (
    <Context.Provider value={{ signedIn, login, logout }}>
      {children}
    </Context.Provider>
  );
}

export function useContextProvider() {
  const ctx = useContext(Context);
  if (!ctx) throw new Error("useContextProvider must be used within a ContextProvider");
  return ctx;
}
