import Image from "next/image"

export default function Header() {
    return (
        <div className="flex flex-col justify-center items-center text-white">
            <Image src={"/trail.svg"} height={100} width={100} alt="trail image"
            className="invert brightness-0"/>
            <h1>TrailFinder</h1>
            <h2>The definitive guide to Athens parks and trails</h2>
        </div>
    )
}