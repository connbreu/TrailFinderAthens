import Image from "next/image"

type Params = {
    imgSrc: string,
    label: string,
}
export default function FeatureItem({imgSrc, label}:Params) {
    return (
        <div className="px-5 flex flex-col items-center justify-center text-white ">
            <Image src={imgSrc} height={50} width={50} alt={imgSrc} 
            className="invert brightness-0"/>
            <label>{label}</label>
        </div>

    )
}    