import Image from "next/image"
import FeatureItem from "./FeatureItem"

export default function Features() {
    return (
        <div className="flex flex-row text-white">
            <FeatureItem imgSrc="/cloud.svg" label="Live Weather" />
            <FeatureItem imgSrc="/location.svg" label="Nearby Trails" />
            <FeatureItem imgSrc="/user_group.svg" label="Join Groups"/>
        </div>
    )
}