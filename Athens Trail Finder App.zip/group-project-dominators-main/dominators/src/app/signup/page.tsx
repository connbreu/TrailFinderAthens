"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Nav from "../signin/components/Nav";
import Input from "../signin/components/Input";
import SignInLink from "../signin/components/SignInLink";

export default function SignUp() {
  const router = useRouter();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [error, setError] = useState("");

  function handleChange(e:any) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e:any) {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    // call your API route that creates a user
    const res = await fetch("/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: formData.name,
        email: formData.email,
        password: formData.password,
      }),
    });

    if (!res.ok) {
      const message = await res.text();
      setError(message || "Signup failed.");
      return;
    }

    router.push("/signin");
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">

        <Nav accountCreated={false} />

        {error && (
          <p className="text-center text-red-600 font-medium mb-4">{error}</p>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">

          <Input
            name="Full Name"
            inputId="name"
            placeholder="John Doe"
            inputType="text"
            formData={formData.name}
            onChange={handleChange}
            errors=""
          />

          <Input
            name="Email Address"
            inputId="email"
            placeholder="you@example.com"
            inputType="email"
            formData={formData.email}
            onChange={handleChange}
            errors=""
          />

          <Input
            name="Password"
            inputId="password"
            placeholder="••••••••"
            inputType="password"
            formData={formData.password}
            onChange={handleChange}
            errors=""
          />

          <Input
            name="Confirm Password"
            inputId="confirmPassword"
            placeholder="••••••••"
            inputType="password"
            formData={formData.confirmPassword}
            onChange={handleChange}
            errors=""
          />

          <button
            type="submit"
            className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700 transition"
          >
            Create Account
          </button>
        </form>

        <SignInLink
          textContent="Already have an account?"
          linkText="Sign in"
        />
      </div>
    </div>
  );
}
