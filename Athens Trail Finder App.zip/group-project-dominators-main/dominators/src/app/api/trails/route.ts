import { NextRequest, NextResponse } from 'next/server';

// Real Athens, GA trails data with actual trail photos
const ATHENS_TRAILS = [
  {
    id: 1,
    name: "North Oconee River Greenway",
    location: "Athens, Georgia",
    distance: "3.5 mi",
    image: "https://cloudfront.traillink.com/photos/north-oconee-river-greenway_24947_sc.jpg",
    description: "A paved greenway trail along the North Oconee River, perfect for walking and biking.",
    surface: "Paved",
    condition: "Excellent",
    trailType: "Greenway"
  },
  {
    id: 2,
    name: "Sandy Creek Nature Center Trail",
    location: "Athens, Georgia",
    distance: "4.2 mi",
    image: "https://assets.simpleviewinc.com/simpleview/image/upload/c_limit,q_75,w_1200/v1/crm/athens/sandy-creek-nature-center-family-hike-credit-acc-leisure-services0-b19c8c575056a36_b19c8e51-5056-a36a-0a781296bb13ee0a.jpg",
    description: "Multiple loop trails through forests and wetlands with nature exhibits.",
    surface: "Natural",
    condition: "Good",
    trailType: "Nature Trail"
  },
  {
    id: 3,
    name: "Cook's Trail",
    location: "Athens, Georgia",
    distance: "2.1 mi",
    image: "https://www.nateshivar.com/wp-content/uploads/2012/04/3-Down-The-Trail-e1335026698923.jpg",
    description: "A peaceful woodland trail connecting residential areas to parks.",
    surface: "Natural",
    condition: "Good",
    trailType: "Hiking Trail"
  },
  {
    id: 4,
    name: "Heritage Trail",
    location: "Athens, Georgia",
    distance: "1.8 mi",
    image: "https://assets.simpleviewinc.com/simpleview/image/upload/c_limit,h_1200,q_75,w_1200/v1/clients/athens/9-11_Memorial_Trail_Sign_web_credit_Bob_Hart_cd15fdb9-f0ae-5102-065bdc9b1c0b96da.png",
    description: "Historic trail showcasing Athens' cultural and architectural heritage.",
    surface: "Paved",
    condition: "Excellent",
    trailType: "Heritage Trail"
  },
  {
    id: 5,
    name: "Firefly Trail",
    location: "Athens, Georgia",
    distance: "3.0 mi",
    image: "https://www.fireflytrail.com/uploads/2/0/5/9/20595634/new-trail-creek-bridge_orig.jpeg",
    description: "Multi-use trail connecting Athens to neighboring communities.",
    surface: "Paved",
    condition: "Excellent",
    trailType: "Rail Trail"
  },
  {
    id: 6,
    name: "Memorial Park Trail",
    location: "Athens, Georgia",
    distance: "1.2 mi",
    image: "https://exploregeorgia.org/sites/default/files/listing_images/profile/2470/memorial-park-bridge-landscape-credit-acc-leisure-services.jpg",
    description: "Easy loop trail around Memorial Park with playground access.",
    surface: "Natural",
    condition: "Good",
    trailType: "Loop Trail"
  },
  {
    id: 7,
    name: "Ben Burton Park Trail",
    location: "Athens, Georgia",
    distance: "2.3 mi",
    image: "https://www.accgov.com/ImageRepository/Document?documentID=46716",
    description: "Scenic trail through Ben Burton Park with access to pond and picnic areas.",
    surface: "Natural",
    condition: "Good",
    trailType: "Park Trail"
  },
  {
    id: 8,
    name: "Middle Oconee River Greenway",
    location: "Athens, Georgia",
    distance: "4.5 mi",
    image: "https://assets.simpleviewinc.com/simpleview/image/upload/c_limit,q_75,w_1200/v1/crm/milledgeville/20220928VisitMilledgeville-181_7810795D-BE36-3592-CC34BFA8F93BBCA7-781076f5a1d0906_781084ed-088c-f7a8-08cf0576ab0db61e.jpg",
    description: "Paved greenway following the Middle Oconee River with beautiful water views.",
    surface: "Paved",
    condition: "Excellent",
    trailType: "Greenway"
  },
  {
    id: 9,
    name: "Southeast Clarke Park Trail",
    location: "Athens, Georgia",
    distance: "1.5 mi",
    image: "https://www.accgov.com/ImageRepository/Document?documentID=91733",
    description: "Community park trail with sports facilities and walking paths.",
    surface: "Paved",
    condition: "Excellent",
    trailType: "Park Trail"
  },
  {
    id: 10,
    name: "Lake Chapman Trail",
    location: "Athens, Georgia",
    distance: "5.2 mi",
    image: "https://trailrunner.com/wp-content/uploads/gravity_forms/4-75c63697a12d8324ad1a983f2950d143/2017/01/sandyck.jpg",
    description: "Moderate trail around Lake Chapman with wildlife viewing opportunities.",
    surface: "Natural",
    condition: "Good",
    trailType: "Lake Trail"
  },
  {
    id: 11,
    name: "State Botanical Garden Trails",
    location: "Athens, Georgia",
    distance: "3.8 mi",
    image: "https://news.uga.edu/wp-content/uploads/2021/03/SBGSummer2020_008.jpg",
    description: "Network of trails through diverse plant collections and natural areas.",
    surface: "Natural",
    condition: "Excellent",
    trailType: "Botanical Trail"
  },
  {
    id: 12,
    name: "Dudley Park Trail",
    location: "Athens, Georgia",
    distance: "0.8 mi",
    image: "https://www.accgov.com/ImageRepository/Document?documentID=55584",
    description: "Short family-friendly trail perfect for a quick walk in the neighborhood.",
    surface: "Paved",
    condition: "Good",
    trailType: "Loop Trail"
  }
];

export async function GET(request: NextRequest) {
  return NextResponse.json({
    success: true,
    trails: ATHENS_TRAILS,
    count: ATHENS_TRAILS.length
  });
}