import connectMongoDB from "../../../../config/mongodb";
import Event from "../../models/eventSchema";
import { NextResponse } from "next/server";
import { NextRequest } from "next/server";


export async function POST(request: NextRequest) {
  const { date, trail, description, user_id } = await request.json();
  console.log(user_id);
  await connectMongoDB();
  const newEvent = await Event.create({ date, trail, description, user_id});
  return Response.json(newEvent);
}

export async function GET() {
    await connectMongoDB();
    const events = await Event.find();
    return NextResponse.json({ events });
}

export async function DELETE(request: NextRequest,) {
  const { id } = await request.json();
  try {
    await connectMongoDB();
    const deletedItem = await Event.findByIdAndDelete(id);

    if (!deletedItem) {
      return NextResponse.json({ message: "Event not found" }, { status: 404 });
    }

    return NextResponse.json({ message: "Event deleted" }, { status: 200 });
  } catch (err) {
    console.error("DELETE /api/event/ error:", err);
    return NextResponse.json(
      { message: "Server error deleting item" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  
  const { id, date, trail, description } = await request.json();

  await connectMongoDB();
  const updatedEvent = await Event.findByIdAndUpdate(id, { date, trail, description });

  return Response.json(updatedEvent);

}