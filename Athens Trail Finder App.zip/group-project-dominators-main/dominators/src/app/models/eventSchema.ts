import mongoose, { Document, Schema, Model } from "mongoose";

export interface IEvent extends Document {
  date: Date;
  trail: string;
  description: string;
  user_id: string;
}

const eventSchema = new Schema<IEvent>({
  date: {type: Date, required: true},
  trail: {type : String, required:true},
  description:  {type: String,  required:true},
  user_id: {type:String, required: true}
});
const Event: Model<IEvent> = mongoose.models.Event || mongoose.model<IEvent>("Event", eventSchema);
export default Event;