"use client";

import { useState, useEffect } from "react";
import Nav from "../components/Nav";
import SubNav from "./components/SubNav";
import Events from "./components/Events";
import Form from "./components/Form";
import { ObjectId } from "mongoose";
import LoginRequiredModal from "./components/LoginRequiredModal";
import { useSession } from "next-auth/react";

export type Event = {
  _id?: ObjectId;
  user_id?: string;
  date: Date;
  trail: string;
  description: string;
};

export default function EventsPage() {
  const { data: session } = useSession();
  const isLoggedIn = !!session?.user;


  const [events, setEvents] = useState<Event[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  const [form, setForm] = useState({
    date: new Date(0),
    trail: "",
    description: "",
  });
  const [submitPost, setSubmitPost] = useState(false);
  const [updateId, setUpdateId] = useState("")

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  // POST events
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (Date.parse(form.date.toString()) < Date.parse(new Date().toString())) {
      alert("The date for the event must be in the future");
      return;
    }
    const newEvent: Event = {
      user_id: session?.user.id,
      ...form,
    };

    try {
      const response = await fetch("/api/events", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newEvent),
      });

      if (!response.ok) {
        throw new Error("Failed to create event");
      } 
      const savedEvent = await response.json();

      setEvents(prev => [...prev, savedEvent]);
      setForm({date: new Date(0), trail: "", description: "" });
      setShowForm(false);
    } catch (error) {
      console.error("Error creating event:", error);
    }
  };

  // GET events
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch("/api/events");
        if (!res.ok) throw new Error("Failed to fetch events");

        const data = await res.json();
        // before setting events, deletes events that have already passed
        data.events.map(async (e:Event) => {
          if (Date.parse(e.date.toString()) < Date.parse(new Date().toString()))
              var response = await fetch(`/api/events`, {
                method: 'DELETE',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({id:e._id}),
              });
        })
        setEvents(data.events); 
        // console.log('Fetched events:', data.events);
      } catch (error) {
        console.error("Error fetching events:", error);
      }
    };

    fetchEvents();
  }, []);
  
// add DELETE functionality so that events are automatically deleted after the date they happen are passed
// will delete if user clicks on delete button on the event or when the date has passed
  const handleDelete = async (e?: React.MouseEvent<HTMLButtonElement>) => {
    const id = e?.currentTarget.id;
    console.log(e?.currentTarget)
    if (!id) return;
    const newId = {
      id: id
    }
    try {
      const response = await fetch(`/api/events`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newId),
      });
      // fetch events again once event is deleted
      const res = await fetch("/api/events");
      const data = await res.json();
      setEvents(data.events); 

    } catch (err: any) {
      console.error('Error deleting item:', err);
    }

  }

  const handleUpdate = async (e: Event) => {
    setSubmitPost(true);
    setForm({date: e.date, trail:e.trail, description:e.description});
    setUpdateId(String(e._id))
    setShowForm(true);
  }
  
  // handles PUT requests to update an event
  const submitUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (Date.parse(form.date.toString()) < Date.parse(new Date().toString())) {
      alert("The date for the event must be in the future");
      return;
    }
    const updatedEvent = {
      id: updateId,
      ...form,
    };

    try {
      const response = await fetch("/api/events", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedEvent),
      });

      if (!response.ok) {
        throw new Error("Failed to create event");
      } 
      // const savedEvent = await response.json();
      const res = await fetch("/api/events");
      if (!res.ok) throw new Error("Failed to fetch events");

      const data = await res.json();

      setEvents(data.events);
      setForm({ date: new Date(0), trail: "", description: "" });
      setShowForm(false);
      setUpdateId("");
    } catch (error) {
      console.error("Error creating event:", error);
    }
    setSubmitPost(false);
  };



  return (
    <div className="min-h-screen bg-green-50 p-0">
      <Nav />

      <div className="mt-4">
        <SubNav
          setShowForm={
            isLoggedIn
              ? setShowForm
              : () => setShowLoginModal(true)  
          }
        />
      </div>

      <Events events={events} handleDelete={handleDelete} handleUpdate={handleUpdate}/>

      {/* Show event form when logged in */}
      {isLoggedIn && showForm && (
        // TODO: make it so the form isn't filled out after trying to edit it when you click create post
        <Form
          form={form}
          setShowForm={setShowForm}
          setSubmitPost={setSubmitPost}
          handleChange={handleChange}
          handleSubmit={submitPost ? submitUpdate : handleSubmit}
          setForm={setForm}
        />
      )}
      {showLoginModal && (
        <LoginRequiredModal onClose={() => setShowLoginModal(false)} />
      )}
    </div>
  );
}
