
type Props = {
    setShowForm: (param: boolean) => void
}

export default function SubNav({setShowForm}:Props){
    return (
        <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-green-800">Group Events & Hikes</h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition cursor-pointer"
        >
          + Create Event
        </button>
      </div>
    )
}