
type Props = {
    name: string,
    type?: string, 
    placeholder?: string,
    handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void,
    value?: string,
}

export default function Input({name, type, placeholder, handleChange, value}:Props){
    return (
        <input
                name={name}
                type={type ? type : ""}
                value={value}
                onChange={handleChange}
                placeholder={placeholder ? placeholder : ""}
                required
                className="w-full border p-2 rounded"
        />
    )
}