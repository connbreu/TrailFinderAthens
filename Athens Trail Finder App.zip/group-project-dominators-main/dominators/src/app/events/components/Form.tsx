import Input from "./Input"

type Props = {
    form: {
        date: Date,
        trail: string,
        description: string,
    },
    setShowForm: (param:boolean) => void,
    handleSubmit: (e: React.FormEvent) => void,
    handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void,
    setSubmitPost: (param:boolean) => void,
    setForm: (param:{date:Date, trail:string, description:string}) => void
}

function toDatetimeLocal(dateString : string): string {
  const dateParse = Date.parse(dateString);
  const date = new Date(dateParse)
  const pad = (n:number) => n.toString().padStart(2, "0");

  return (
    date.getFullYear() +
    "-" +
    pad(date.getMonth() + 1) +
    "-" +
    pad(date.getDate()) +
    "T" +
    pad(date.getHours()) +
    ":" +
    pad(date.getMinutes())
  );
  }

export default function Form({form, setShowForm, handleSubmit, handleChange, setSubmitPost, setForm}:Props){
  console.log(`form date: ${typeof(form.date)} new date: ${typeof(new Date(0))}`)
    return (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
          <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md relative">
            <button
              onClick={() => {setShowForm(false); setSubmitPost(false); setForm({date: new Date(0), trail:"", description:""})}}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 cursor-pointer"
            >
              ✕
            </button>
            <h2 className="text-xl font-semibold mb-4 text-green-700">Create a New Event</h2>
            <form onSubmit={handleSubmit} className="space-y-3">
              <Input name="date" type="datetime-local"  handleChange={handleChange} 
              value={typeof(form.date) != typeof(new Date(0)) ? toDatetimeLocal(String(form.date)): ""}/>
              <Input name="trail" placeholder="Trail name" value={form.trail} handleChange={handleChange} />
              <textarea
                name="description"
                placeholder="Event description..."
                value={form.description}
                onChange={handleChange}
                required
                className="w-full border p-2 rounded h-24"
              />
              <button
                type="submit"
                className="bg-green-600 text-white w-full py-2 rounded-lg hover:bg-green-700 transition cursor-pointer"
              >
                Post Event
              </button>
            </form>
          </div>
        </div>
    )
}