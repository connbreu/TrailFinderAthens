"use client";

import { Event } from "../page";
import EventCard from "./EventCard";
import WrapperCard from "./WrapperCard";

export default function Events({
  events,
  handleDelete,
  handleUpdate,
}: {
  events: Event[];
  handleDelete: (e: React.MouseEvent<HTMLButtonElement>) => void;
  handleUpdate: (e: Event) => void;
}) {
  return (
    <div>
      {events.length === 0 ? (
        <p className="text-gray-500">
          No events yet. Click “Create Event” to start one!
        </p>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event: Event) => (
            <WrapperCard key={event._id?.toString()}>
              <EventCard
                event={event}
                handleDelete={handleDelete}
                handleUpdate={handleUpdate}
              />
            </WrapperCard>
          ))}
        </div>
      )}
    </div>
  );
}
