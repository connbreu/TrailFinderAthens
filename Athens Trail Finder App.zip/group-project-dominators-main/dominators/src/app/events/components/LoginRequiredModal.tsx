"use client";

type Props = {
  onClose: () => void;
};

export default function LoginRequiredModal({ onClose }: Props) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl p-6 w-80 animate-fadeIn">
        <h2 className="text-xl font-bold text-gray-800 mb-2">Login Required</h2>
        <p className="text-gray-600 mb-6">
          You need to be logged in to add a new event.
        </p>

        <div className="flex flex-col gap-3">
          {/* Redirect to your existing login page */}
          <button
            onClick={() => (window.location.href = "/signin")}
            className="bg-green-600 hover:bg-green-700 text-white py-2 rounded-md transition"
          >
            Go to Login
          </button>

          <button
            onClick={onClose}
            className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-2 rounded-md transition"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
