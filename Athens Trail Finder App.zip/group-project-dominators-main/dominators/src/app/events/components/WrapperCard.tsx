"use client";

type Props = {
  children: React.ReactNode;
};

export default function WrapperCard({ children }: Props) {
  return (
    <div
      className="
        bg-white/95 
        rounded-2xl 
        p-6 
        shadow-md 
        border 
        border-green-300 
        relative 
        overflow-hidden 
        hover:shadow-lg 
        transition-shadow
      "
    >
      {/* Soft nature gradient strip */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 to-green-600"></div>

      {/* Decorative leaf background (very subtle) */}
      <div className="absolute bottom-0 right-0 opacity-10 pointer-events-none select-none">
        <span className="text-8xl">🌿</span>
      </div>

      <div className="relative z-10">{children}</div>
    </div>
  );
}
