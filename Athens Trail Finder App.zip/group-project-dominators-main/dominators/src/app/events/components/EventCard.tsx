"use client";
import { Event } from "../page"
import { useSession } from "next-auth/react";


export default function EventCard({event, handleDelete, handleUpdate}:{event:Event, 
    handleDelete: (e: React.MouseEvent<HTMLButtonElement>) => void,
    handleUpdate: (e: Event) => void
}){
    const newDate = new Date(event.date);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const { data: session, status } = useSession();
    
    // const isLoggedIn = !!session?.user;
    console.log(`${event.trail} ,${event._id}`)

    return (
        <div className="group relative p-4 rounded-lg transition">
            <h2 className="font-semibold text-lg text-green-700">
                {event.trail}
            </h2>

            <p className="text-sm text-gray-500">
                {`${months[newDate.getMonth()]} ${newDate.getDate()}, ${newDate.getFullYear()} at ${
                newDate.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`}
            </p>

            <p className="mt-2 text-gray-700">{event.description}</p>

            {event.user_id === session?.user.id && (
                <div className="absolute top-2 right-2 flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <button id={String(event._id)} onClick={handleDelete} className="cursor-pointer">
                    <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="size-6"
                    >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                    />
                    </svg>
                </button>

                <button className="text-sm underline cursor-pointer" onClick={() => handleUpdate(event)} >
                    Edit
                </button>
                </div>
            )}
            </div>

    )
}