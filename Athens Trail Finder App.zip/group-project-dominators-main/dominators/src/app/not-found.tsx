import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-green-50 px-6">
      <div className="bg-white/90 p-10 rounded-2xl shadow-xl border border-green-200 max-w-md w-full text-center animate-fadeIn">
        
        {/* Symbolic nature emoji */}
        <div className="text-6xl mb-4">🌲</div>

        <h2 className="text-3xl font-bold text-green-700 mb-2">
          Page Not Found
        </h2>

        <p className="text-gray-700 mb-6">
          The page you are looking for doesn’t exist.
        </p>

        <Link
          href="/trails"
          className="inline-block bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition shadow-md"
        >
          Return Home
        </Link>

        <div className="mt-6 text-gray-400 text-sm">
          You can always explore from the homepage 🌿
        </div>
      </div>
    </div>
  );
}
