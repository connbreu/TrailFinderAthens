"use client";

import React, { useState, useEffect } from "react";
import Nav from "../components/Nav";
import SearchBar from "./components/SearchBar";
import TrailCards from "./components/TrailCards";
import { FavoritesProvider, useFavorites } from "./components/FavoritesContext";

export interface Trail {
  id: number;
  name: string;
  location: string;
  distance: string;
  image: string;
  description?: string;
  surface?: string;
  condition?: string;
  trailType?: string;
}

export default function TrailsPage() {
  return (
    <FavoritesProvider>
      <TrailsPageContent />
    </FavoritesProvider>
  );
}

function TrailsPageContent() {
  const [search, setSearch] = useState("");
  const [trails, setTrails] = useState<Trail[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [distanceFilter, setDistanceFilter] = useState<'all' | 'short' | 'medium' | 'long'>('all');
  const { favorites } = useFavorites();

  // Fetch trails from API on component mount
  useEffect(() => {
    const fetchTrails = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const response = await fetch('/api/trails');
        
        if (!response.ok) {
          throw new Error('Failed to fetch trails');
        }

        const data = await response.json();
        
        if (data.success && data.trails) {
          setTrails(data.trails);
        } else {
          throw new Error(data.message || 'Failed to load trails');
        }
      } catch (err) {
        console.error('Error fetching trails:', err);
        setError(err instanceof Error ? err.message : 'Failed to load trails');
        setTrails([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTrails();
  }, []);

  // Filter trails based on search
  let filteredTrails = trails.filter((trail) =>
    trail.name.toLowerCase().includes(search.toLowerCase()) ||
    trail.location?.toLowerCase().includes(search.toLowerCase())
  );

  // Filter by favorites if enabled
  if (showFavoritesOnly) {
    filteredTrails = filteredTrails.filter(trail => favorites.includes(trail.id));
  }

  // Filter by distance
  if (distanceFilter !== 'all') {
    filteredTrails = filteredTrails.filter(trail => {
      const distance = parseFloat(trail.distance);
      if (distanceFilter === 'short') return distance <= 2;
      if (distanceFilter === 'medium') return distance > 2 && distance <= 4;
      if (distanceFilter === 'long') return distance > 4;
      return true;
    });
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Navbar */}
      <Nav />

      {/* Search bar*/}
      <div className="max-w-6xl mx-auto px-4 mt-8 mb-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <SearchBar search={search} setSearch={setSearch} />
            
            {/* Filter buttons */}
            <div className="mt-4 flex flex-wrap gap-3">
              {/* Favorites filter button */}
              <button
                onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${
                  showFavoritesOnly
                    ? 'bg-red-500 text-white'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                </svg>
                {showFavoritesOnly ? 'Show All Trails' : `Show Favorites Only (${favorites.length})`}
              </button>

              {/* Distance filter dropdown */}
              <select
                value={distanceFilter}
                onChange={(e) => setDistanceFilter(e.target.value as any)}
                className="px-4 py-2 rounded-lg font-medium bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <option value="all">All Distances</option>
                <option value="short">Short (2 mi or less)</option>
                <option value="medium">Medium (2-4 mi)</option>
                <option value="long">Long (4+ mi)</option>
              </select>

              {/* Clear filters button */}
              {(showFavoritesOnly || distanceFilter !== 'all') && (
                <button
                  onClick={() => {
                    setShowFavoritesOnly(false);
                    setDistanceFilter('all');
                  }}
                  className="px-4 py-2 rounded-lg font-medium bg-gray-200 text-gray-700 hover:bg-gray-300 transition-colors"
                >
                  Clear Filters
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex justify-center items-center py-20">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading trails...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <h3 className="text-red-800 font-semibold mb-2">Error Loading Trails</h3>
            <p className="text-red-600">{error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
            >
              Try Again
            </button>
          </div>
        </div>
      )}

      {/* Trail cards */}
      {!isLoading && !error && (
        <>
          {filteredTrails.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-gray-600 text-lg">
                {showFavoritesOnly 
                  ? 'No favorite trails yet. Click the heart icon on trails to add them!' 
                  : search 
                    ? `No trails found matching "${search}"` 
                    : 'No trails available'}
              </p>
            </div>
          ) : (
            <div className="max-w-6xl mx-auto px-4">
              <p className="text-gray-600 mb-4">
                Found {filteredTrails.length} trail{filteredTrails.length !== 1 ? 's' : ''}
                {showFavoritesOnly && ' in your favorites'}
              </p>
              <TrailCards filteredTrails={filteredTrails} />
            </div>
          )}
        </>
      )}
    </div>
  );
}