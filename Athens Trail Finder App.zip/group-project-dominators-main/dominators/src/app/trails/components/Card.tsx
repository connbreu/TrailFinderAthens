"use client";

import Image from "next/image";
import Link from 'next/link';
import { useFavorites } from './FavoritesContext';

type Props = {
  id: number;
  image: string;
  name: string;
  location: string;
  distance: string;
};

export default function Card({ id, image, name, location, distance }: Props) {
  const { isFavorite, toggleFavorite } = useFavorites();
  const favorite = isFavorite(id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation when clicking heart
    e.stopPropagation();
    toggleFavorite(id);
  };

  return (
    <Link href={`/trails/${id}`}>
      <div className="bg-white rounded-xl overflow-hidden shadow hover:shadow-lg transition-shadow cursor-pointer relative">
        {/* Favorite button */}
        <button
          onClick={handleFavoriteClick}
          className="absolute top-3 right-3 z-10 p-2 bg-white/90 rounded-full hover:bg-white transition-colors shadow-md"
          aria-label={favorite ? "Remove from favorites" : "Add to favorites"}
        >
          <svg
            className={`w-6 h-6 transition-colors ${
              favorite ? 'fill-red-500 stroke-red-500' : 'fill-none stroke-gray-600'
            }`}
            viewBox="0 0 24 24"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
            />
          </svg>
        </button>

        {/* Image container with fixed aspect ratio */}
        <div className="relative w-full aspect-[2/1]">
          <Image
            src={image}
            alt={name}
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        </div>

        {/* Card content */}
        <div className="p-4">
          <h2 className="text-lg font-semibold">{name}</h2>
          <p className="text-sm text-gray-600">{location}</p>
          <p className="text-sm font-medium mt-2">{distance}</p>
        </div>
      </div>
    </Link>
  );
}