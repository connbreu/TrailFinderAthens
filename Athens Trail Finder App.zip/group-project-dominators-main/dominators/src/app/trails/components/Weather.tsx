'use client';

import React, { useState, useEffect } from 'react';

interface WeatherData {
  temp: number;
  condition: string;
  icon: string;
  humidity: number;
  windSpeed: number;
  feelsLike: number;
}

export default function Weather() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const apiKey = process.env.NEXT_PUBLIC_WEATHER_API_KEY;
        
        if (!apiKey || apiKey === 'your_weather_api_key_here') {
          setIsLoading(false);
          return;
        }

        const response = await fetch(
          `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=Athens,GA&aqi=no`
        );

        if (!response.ok) {
          throw new Error('Failed to fetch weather');
        }

        const data = await response.json();

        setWeather({
          temp: Math.round(data.current.temp_f),
          condition: data.current.condition.text,
          icon: data.current.condition.icon,
          humidity: data.current.humidity,
          windSpeed: Math.round(data.current.wind_mph),
          feelsLike: Math.round(data.current.feelslike_f),
        });
      } catch (error) {
        console.error('Error fetching weather:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchWeather();
  }, []);

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 animate-pulse">
        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
        <div className="h-8 bg-gray-200 rounded w-1/2 mb-2"></div>
        <div className="h-4 bg-gray-200 rounded w-2/3"></div>
      </div>
    );
  }

  if (!weather) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">Athens, GA Weather</h3>
          <p className="text-4xl font-bold text-gray-900 mt-2">{weather.temp}°F</p>
          <p className="text-gray-600 mt-1">{weather.condition}</p>
        </div>
        <div>
          <img 
            src={`https:${weather.icon}`} 
            alt={weather.condition}
            className="w-20 h-20"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
        <div className="text-center">
          <p className="text-xs text-gray-500 font-medium">Feels Like</p>
          <p className="text-lg font-semibold text-gray-900">{weather.feelsLike}°F</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-500 font-medium">Humidity</p>
          <p className="text-lg font-semibold text-gray-900">{weather.humidity}%</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-500 font-medium">Wind</p>
          <p className="text-lg font-semibold text-gray-900">{weather.windSpeed} mph</p>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200">
        <p className="text-sm text-gray-600 text-center">
          🌲 Great conditions for hiking today!
        </p>
      </div>
    </div>
  );
}