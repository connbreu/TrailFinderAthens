type Props = {
    search: string,
    setSearch: (arg0: string) => void,
}
export default function SearchBar({search, setSearch}:Props){
    return <div className="flex justify-center mt-8 mb-6">
        <input
          type="text"
          placeholder="Search for a trail..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full max-w-md px-4 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
}