import Card from "./Card";
import { Trail } from "../page";

type Props = {
    filteredTrails: Trail[]
}

export default function TrailCards({filteredTrails}:Props) {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-6 pb-10">
        {filteredTrails.length > 0 ? (
          filteredTrails.map((trail, index) => (
            <Card key={index} id={trail.id} image={trail.image} name={trail.name} location={trail.location} distance={trail.distance}/>
          ))
        ) : (
          <p className="text-center col-span-full text-gray-500">
            No trails found.
          </p>
        )}
      </div>
    )
}