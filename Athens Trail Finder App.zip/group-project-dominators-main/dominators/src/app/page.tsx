import Image from "next/image";
import { ContextProvider } from "./components/Context";
import Header from "./components/Header";
import Features from "./components/Features";
import Button from "./components/Button";


export default function Home() {
  return (
      <div className="bg-[url(/athens_trail_bg.jpg)] min-h-screen bg-cover bg-center bg-no-repeat">
        <div className="absolute inset-0 bg-black/30 pointer-events-none"></div>
        <div className="relative z-10">
            <ContextProvider>
              <div className="flex flex-col items-center content-center pt-40">
                <Header />
                <Features />
                <Button 
                textContent="Explore trails and Parks"
                src='/trails'
                type='trails'
                />
              </div>

          </ContextProvider>
        </div>
        
      </div>

  );
}
