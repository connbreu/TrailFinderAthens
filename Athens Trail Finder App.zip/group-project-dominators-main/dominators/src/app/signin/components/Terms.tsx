import Link from "next/link"

export default function Terms() {
    return (
        <div>
            <label className="flex items-start">
            <input 
              type="checkbox" 
              className="w-4 h-4 mt-1 text-lime-500 border-gray-300 rounded focus:ring-lime-500"
              required
            />
            <span className="ml-2 text-sm text-gray-600">
              I agree to the{' '}
              <Link href="/terms" className="text-lime-600 hover:text-lime-700 font-semibold">
                Terms of Service
              </Link>
              {' '}and{' '}
              <Link href="/privacy" className="text-lime-600 hover:text-lime-700 font-semibold">
                Privacy Policy
              </Link>
            </span>
          </label>
        </div>
    )
}