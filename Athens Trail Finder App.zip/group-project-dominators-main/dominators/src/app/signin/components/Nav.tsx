import Image from "next/image"

type Props = {
  accountCreated: boolean
}
export default function Nav({accountCreated}:Props){
  
    return (
        <div className="flex flex-col items-center mb-8">
              <Image 
                src="/trail.svg" 
                height={60} 
                width={60} 
                alt="TrailFinder logo"
                className="mb-4"
              />
              <h1 className="text-3xl font-bold text-gray-800">{accountCreated ? "Welcome back!" : "Create account"}</h1>
              <p className="text-gray-600 mt-2">{accountCreated ? "Sign in to explore trails" : "Join TrailFinder today"}</p>
            </div>
    )
    
}