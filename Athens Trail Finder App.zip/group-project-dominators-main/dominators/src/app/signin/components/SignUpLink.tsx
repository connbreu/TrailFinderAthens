
import Link from "next/link"

type Props = {
  textContent: string,
  linkText: string,
}

export default function SignUpLink ({textContent, linkText}: Props) {
    return (
        <p className="text-center text-gray-600 mt-6">
          {textContent}{' '}
          <Link href='/signup' className="text-lime-600 hover:text-lime-700 font-semibold">
            {linkText}
          </Link>
        </p>
    )
}