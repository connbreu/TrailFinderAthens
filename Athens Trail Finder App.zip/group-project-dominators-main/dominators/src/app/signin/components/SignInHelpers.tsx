import Link from "next/link"

export default function SingInHelpers(){
    return (
        <div className="flex items-center justify-between">
            <label className="flex items-center">
              <input 
                type="checkbox" 
                className="w-4 h-4 text-lime-500 border-gray-300 rounded focus:ring-lime-500"
              />
              <span className="ml-2 text-sm text-gray-600">Remember me</span>
            </label>
            <Link href="/forgot-password" className="text-sm text-lime-600 hover:text-lime-700 font-semibold">
              Forgot password?
            </Link>
          </div>
    )
}