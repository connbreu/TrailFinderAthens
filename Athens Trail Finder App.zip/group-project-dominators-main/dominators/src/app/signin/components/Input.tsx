type Props = {
  name: string;
  inputType?: string; // "text", "email", "password", etc.
  formData: string;
  placeholder: string;
  errors: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  inputId: string;
};

export default function Input({
  name,
  inputType,
  formData,
  placeholder,
  errors,
  onChange,
  inputId
}: Props) {
  return (
    <div>
      <label htmlFor={inputId} className="block text-sm font-semibold text-gray-700 mb-2">
        {name}
      </label>

      <input
        type={inputType ?? "text"}   
        id={inputId}
        name={inputId}
        value={formData}
        onChange={onChange}
        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 transition-all ${
          errors
            ? "border-red-500 focus:ring-red-500"
            : "border-gray-300 focus:ring-lime-500"
        }`}
        placeholder={placeholder}
      />

      {errors && <p className="text-red-500 text-sm mt-1">{errors}</p>}
    </div>
  );
}
