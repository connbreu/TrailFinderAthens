"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signIn , useSession} from "next-auth/react";
import { doCredentialLogin } from "app/actions";
import Nav from "./components/Nav";
import Input from "./components/Input";
import SignInHelpers from "./components/SignInHelpers";
import SignUpLink from "./components/SignUpLink";
import {FormEvent} from "react"

export default function SignIn() {
  const {update} = useSession();
  const router = useRouter();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const response = await doCredentialLogin(formData);


    await update();

    if (response?.error) {
        const message = response.error.message || "An error occurred";
        setError(message);
      } else {
        router.push("/");
        // router.refresh();
      }

    if(!response?.error) router.push("/trails");
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-lime-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">

        <Nav accountCreated={true} />

        {error && <p className="text-red-600 mb-4">{error}</p>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            name="Email Address"
            inputId="email"
            placeholder="you@example.com"
            inputType="email"
            formData={formData.email}
            onChange={handleChange}
            errors=""
          />

          <Input
            name="Password"
            inputId="password"
            placeholder="••••••••"
            inputType="password"
            formData={formData.password}
            onChange={handleChange}
            errors=""
          />

          <SignInHelpers />

          <button className="w-full bg-green-600 text-white py-3 rounded-xl">
            Sign In
          </button>
        </form>

        <SignUpLink
          textContent="Don't have an account?"
          linkText="Sign up"
        />
      </div>
    </div>
  );
}
