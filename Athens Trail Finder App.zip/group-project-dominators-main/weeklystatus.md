made a figma markup for our project going to get started on the front end this week. 11/03/25

Jack made a basic splash page that has buttons to other pages that will be made in the future. It has some styling and more boilerplate was added, like a context provider that can be used for more components other than the ones that were used on the home page.

Krish made a signup/login page, this include a login button, create account button, an option to sign in with google or facebook. 
